# Final-Project
Team 5 (Jenny, Khadija, Mikhail)
Angel's R US (e-commerce page for babies and new mothers)

# Tasks
https://github.com/reanderson89/jfsjd-final-project

# Wireframe
https://docs.google.com/document/d/19HefUTJml-SPmAvQyeabblEEQJ4RRSHqkXQ43xYWzpI/edit

# Website Deployment
https://jennytheodore.github.io/Final-Project/
